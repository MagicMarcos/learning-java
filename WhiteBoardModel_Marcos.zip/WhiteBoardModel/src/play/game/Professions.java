package play.game;

public enum Professions {
    WARRIOR, PALADIN , MONK , MAGE , RANGER
}